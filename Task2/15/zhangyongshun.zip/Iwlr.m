function YPoint = Iwlr(x,y,k)
    m = size(x,1);
    YPoint = zeros(1,size(y,1));
    for tmp = 1:1:m,
      YPoint(tmp) = IwlrSinglePoint(x(tmp,:),x,y,k);
    end;

