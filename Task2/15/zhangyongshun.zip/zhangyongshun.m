load q2x.dat;
load q2y.dat;

[q2x,ind] = sort(q2x);
length = size(q2x,1);
y = zeros(length,1);

for i = 1:1:length,
  y(i) = q2y(ind(i));
end; 
x = [ones(size(q2x,1),1) q2x];

plot(q2x,y,'rx');
title('Xiaoshun Plot');
xlabel('X');
ylabel('Y');
hold on;

q2y = Iwlr(x,y,1);
plot(q2x,q2y,'b-');
q2y = Iwlr(x,y,0.1);
plot(q2x,q2y,'k-');
q2y = Iwlr(x,y,0.05);
plot(q2x,q2y,'y-');
q2y = Iwlr(x,y,0.01);
plot(q2x,q2y,'g-');

legend('k=1','k=0.1','k=0.05','k=0.01');

print -dpng 'zhangyongshun.png';




