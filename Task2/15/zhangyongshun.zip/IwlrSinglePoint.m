function SingleYPoint = IwlrSinglePoint(RowTestPoint,x,y,k)
    m = size(x,1);
    w = zeros(m,m);
    for tmp = 1:1:m,
      sub = RowTestPoint - x(tmp,:);
      w(tmp,tmp) = exp((-1 / (2 * k ^ 2)) * (sub * sub'));
    end;
    theta = pinv(x' * w * x) * x' * w * y;
    SingleYPoint = RowTestPoint * theta; 

